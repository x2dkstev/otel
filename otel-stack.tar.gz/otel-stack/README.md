# otel-stack

Two Helm charts for deploying the OpenTelemetry Operator and a contrib Collector instance.

```
otel-stack/
├── otel-operator/             # Wraps the upstream opentelemetry-operator chart
│   ├── Chart.yaml
│   ├── values.yaml
│   └── templates/
│       ├── _helpers.tpl
│       └── namespace.yaml
│
└── otel-collector-contrib/    # OpenTelemetryCollector CR (contrib distro)
    ├── Chart.yaml
    ├── values.yaml
    └── templates/
        ├── _helpers.tpl
        ├── collector.yaml       ← OpenTelemetryCollector CR
        ├── serviceaccount.yaml
        ├── clusterrole.yaml     ← RBAC for k8sattributes processor
        └── servicemonitor.yaml  ← optional, requires Prometheus Operator
```

---

## Prerequisites

| Tool | Version |
|------|---------|
| Helm | ≥ 3.10 |
| kubectl | ≥ 1.25 |
| cert-manager | ≥ 1.13 (or disable in values) |

---

## 1. Install the OpenTelemetry Operator

```bash
# Add & update the upstream repo
helm repo add open-telemetry https://open-telemetry.github.io/opentelemetry-helm-charts
helm repo update

# Download subchart dependencies
cd otel-operator
helm dependency build

# Install into its own namespace
helm upgrade --install otel-operator . \
  --namespace opentelemetry-operator-system \
  --create-namespace \
  --values values.yaml \
  --wait
```

> **No cert-manager?** Pass `--set opentelemetry-operator.admissionWebhooks.certManager.enabled=false`

---

## 2. Deploy the contrib Collector

```bash
cd ../otel-collector-contrib

helm upgrade --install otel-collector . \
  --namespace observability \
  --create-namespace \
  --values values.yaml \
  --wait
```

### Verify

```bash
# Operator pod
kubectl get pods -n opentelemetry-operator-system

# Collector CR status
kubectl get opentelemetrycollector -n observability

# Collector pod
kubectl get pods -n observability

# Live pipeline logs (debug exporter output)
kubectl logs -n observability \
  -l app.kubernetes.io/managed-by=opentelemetry-operator \
  -f
```

---

## Sending test telemetry

Port-forward the OTLP endpoints locally:

```bash
kubectl port-forward -n observability \
  svc/otel-collector-otel-collector-contrib-collector \
  4317:4317 4318:4318
```

Then use `telemetrygen` (or any OTLP SDK) to send traces:

```bash
# Install telemetrygen
go install github.com/open-telemetry/opentelemetry-collector-contrib/cmd/telemetrygen@latest

# Send 100 traces
telemetrygen traces --otlp-insecure --traces 100
```

---

## Pointing at a real backend

Edit `otel-collector-contrib/values.yaml` and uncomment the `otlp/backend` exporter block:

```yaml
config:
  exporters:
    otlp/backend:
      endpoint: "https://your-backend:4317"
      headers:
        Authorization: "Api-Token ${env:DT_API_TOKEN}"
```

Add an `env:` entry to supply the secret:

```yaml
env:
  - name: DT_API_TOKEN
    valueFrom:
      secretKeyRef:
        name: dynatrace-token
        key: api-token
```

Then add `otlp/backend` to your pipeline exporters lists and redeploy.

---

## Upgrading

```bash
helm repo update
# Bump the dependency version in otel-operator/Chart.yaml, then:
cd otel-operator && helm dependency build
helm upgrade otel-operator . -n opentelemetry-operator-system --values values.yaml

# Bump appVersion / image.tag in otel-collector-contrib/values.yaml, then:
helm upgrade otel-collector ../otel-collector-contrib -n observability --values ../otel-collector-contrib/values.yaml
```
