{{/*
Expand the name of the chart.
*/}}
{{- define "otel-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "otel-operator.labels" -}}
helm.sh/chart: {{ include "otel-operator.name" . }}-{{ .Chart.Version }}
app.kubernetes.io/name: {{ include "otel-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}
