{{/*
Expand the name of the chart.
*/}}
{{- define "otel-collector-contrib.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Full name
*/}}
{{- define "otel-collector-contrib.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name (include "otel-collector-contrib.name" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "otel-collector-contrib.labels" -}}
helm.sh/chart: {{ include "otel-collector-contrib.name" . }}-{{ .Chart.Version }}
app.kubernetes.io/name: {{ include "otel-collector-contrib.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "otel-collector-contrib.selectorLabels" -}}
app.kubernetes.io/name: {{ include "otel-collector-contrib.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
ServiceAccount name
*/}}
{{- define "otel-collector-contrib.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "otel-collector-contrib.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
